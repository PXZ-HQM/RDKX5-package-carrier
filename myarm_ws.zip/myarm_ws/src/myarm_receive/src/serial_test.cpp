#include <ros/ros.h>
#include <serial/serial.h>

int main(int argc, char** argv) {
    ros::init(argc, argv, "serial_test");
    serial::Serial ser;
    try {
        ser.setPort("/dev/ttyUSB0");
        ser.setBaudrate(115200);
        ser.open();
        if (ser.isOpen()) {
            ROS_INFO("Serial port opened!");
        } else {
            ROS_ERROR("Serial port failed to open!");
        }
    } catch (std::exception& e) {
        ROS_ERROR_STREAM("Exception: " << e.what());
    }
    return 0;
}