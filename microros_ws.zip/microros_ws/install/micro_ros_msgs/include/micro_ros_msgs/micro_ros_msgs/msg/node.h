// generated from rosidl_generator_c/resource/idl.h.em
// with input from micro_ros_msgs:msg/Node.idl
// generated code does not contain a copyright notice

#ifndef MICRO_ROS_MSGS__MSG__NODE_H_
#define MICRO_ROS_MSGS__MSG__NODE_H_

#include "micro_ros_msgs/msg/detail/node__struct.h"
#include "micro_ros_msgs/msg/detail/node__functions.h"
#include "micro_ros_msgs/msg/detail/node__type_support.h"

#endif  // MICRO_ROS_MSGS__MSG__NODE_H_
