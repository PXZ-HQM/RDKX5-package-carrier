^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package micro_ros_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

3.0.1 (2024-02-01)
------------------
* Add contributing file (`#9 <https://github.com/micro-ROS/micro_ros_msgs/issues/9>`_) (`#10 <https://github.com/micro-ROS/micro_ros_msgs/issues/10>`_)
* Update package.xml (`#4 <https://github.com/micro-ROS/micro_ros_msgs/issues/4>`_) (`#5 <https://github.com/micro-ROS/micro_ros_msgs/issues/5>`_)

3.0.0 (2023-06-06)
------------------

1.0.0 (2021-08-30)
------------------
* Remove not necessary dependencies (`#1 <https://github.com/micro-ROS/micro_ros_msgs/issues/1>`_)
* Add issue template
* Add msg definitions used by micro-ROS graph manager
* Update README.md
