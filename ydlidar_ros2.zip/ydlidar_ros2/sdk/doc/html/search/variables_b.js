var searchData=
[
  ['scan_5ffrequence',['scan_frequence',['../structnode__info.html#a718a8a2f94497d5edea2be4550f74348',1,'node_info']]],
  ['scan_5fnode_5fbuf',['scan_node_buf',['../classydlidar_1_1_y_dlidar_driver.html#a486f56ec5c3459774e6b395ef8bd202b',1,'ydlidar::YDlidarDriver']]],
  ['scan_5fnode_5fcount',['scan_node_count',['../classydlidar_1_1_y_dlidar_driver.html#a106fc563bb42f19e84e8d9db1e7856fe',1,'ydlidar::YDlidarDriver']]],
  ['scan_5ftime',['scan_time',['../struct_laser_config.html#af40c5e3902bb931e337ea400682e5636',1,'LaserConfig']]],
  ['serialnum',['serialnum',['../structdevice__info.html#abf23e35480aff36d846085ca6fd0eec3',1,'device_info']]],
  ['stamp',['stamp',['../structnode__info.html#a92f30331da1d7d95f9998dcd3886574c',1,'node_info::stamp()'],['../struct_laser_scan.html#ad3a1d87ff071e54fa7310356f87dfc20',1,'LaserScan::stamp()']]],
  ['status',['status',['../structdevice__health.html#ac3425f5555ecbb5a0da03b4cabe2777c',1,'device_health']]]
];
