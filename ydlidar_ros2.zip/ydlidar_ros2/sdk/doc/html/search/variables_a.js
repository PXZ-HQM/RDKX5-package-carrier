var searchData=
[
  ['range',['range',['../struct_laser_point.html#a11f1cc1b1b04456edcfd30254aaa5e08',1,'LaserPoint']]],
  ['rate',['rate',['../structsampling__rate.html#a8d860fbedd930d2022fe7bb6cf1f78b6',1,'sampling_rate']]],
  ['read_5ftimeout_5fconstant',['read_timeout_constant',['../structserial_1_1_timeout.html#a099244649dec66b6e0548480edeb2b9f',1,'serial::Timeout']]],
  ['read_5ftimeout_5fmultiplier',['read_timeout_multiplier',['../structserial_1_1_timeout.html#a64412753eb2edf1621716dd9f1a4e71e',1,'serial::Timeout']]]
];
